from django.apps import AppConfig


class CoursinaryAppConfig(AppConfig):
    name = 'coursinary_app'
